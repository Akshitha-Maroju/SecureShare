import React, { useState } from "react";
import axios from "axios";
import CryptoJS from "crypto-js";
import ReactDOM from "react-dom/client";

function App() {
  const [file, setFile] = useState(null);
  const [password, setPassword] = useState("");
  const [link, setLink] = useState("");
  const [encryptedData, setEncryptedData] = useState("");
  const [decryptPassword, setDecryptPassword] = useState("");
  const [status, setStatus] = useState("");

  const handleEncryptAndUpload = () => {
    if (!file || !password) {
      setStatus("Please select a file and enter a password.");
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      const encrypted = CryptoJS.AES.encrypt(e.target.result, password).toString();
      const blob = new Blob([encrypted], { type: "text/plain" });
      const formData = new FormData();
      formData.append("file", blob, file.name + ".enc");

      try {
        const res = await axios.post("http://localhost:5000/upload", formData);
        setLink(res.data.link);
        setStatus("File uploaded successfully!");
      } catch (err) {
        setStatus("Upload failed.");
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDownloadAndDecrypt = async () => {
    try {
      const res = await axios.get(link, { responseType: "text" });
      setEncryptedData(res.data);
      const bytes = CryptoJS.AES.decrypt(res.data, decryptPassword);
      const originalData = bytes.toString(CryptoJS.enc.Utf8);
      if (!originalData) throw new Error();
      const element = document.createElement("a");
      element.setAttribute("href", originalData);
      element.setAttribute("download", "decrypted_file");
      element.click();
      setStatus("File decrypted and downloaded.");
    } catch {
      setStatus("Decryption failed. Wrong password or corrupted file.");
    }
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h1>🔐 SecureShare</h1>
      <h3>Encrypt and Upload</h3>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleEncryptAndUpload}>Encrypt & Upload</button>
      {link && <p>Download Link: <a href={link}>{link}</a></p>}
      <h3>Decrypt</h3>
      <input type="password" placeholder="Password" onChange={(e) => setDecryptPassword(e.target.value)} />
      <button onClick={handleDownloadAndDecrypt}>Download & Decrypt</button>
      <p>Status: {status}</p>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
