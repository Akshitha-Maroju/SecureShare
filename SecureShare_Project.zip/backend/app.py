from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
import os, uuid, time

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
EXPIRY_SECONDS = 600
file_timestamps = {}

@app.route('/upload', methods=['POST'])
def upload():
    uploaded_file = request.files['file']
    file_id = str(uuid.uuid4()) + "_" + uploaded_file.filename
    filepath = os.path.join(UPLOAD_FOLDER, file_id)
    uploaded_file.save(filepath)
    file_timestamps[file_id] = time.time()
    return jsonify({"link": f"http://localhost:5000/download/{file_id}"})

@app.route('/download/<file_id>', methods=['GET'])
def download(file_id):
    timestamp = file_timestamps.get(file_id)
    if not timestamp:
        return "❌ Link not found", 404
    if time.time() - timestamp > EXPIRY_SECONDS:
        file_timestamps.pop(file_id)
        return "❌ Link expired", 410
    filepath = os.path.join(UPLOAD_FOLDER, file_id)
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True)
    return "❌ File missing", 404

if __name__ == "__main__":
    app.run(debug=True)
